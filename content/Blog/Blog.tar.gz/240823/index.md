---
title: Niet naar Huis
date: 2024-08-23
hero_classes: text-dark title-h1h2 overlay-light hero-large parallax
hero_image: pexels-toa-heftiba-şinca-1194420.jpg
blog_url: /blog
show_sidebar: true
show_breadcrumbs: true
show_pagination: true
categories:
  - Blog
tags:
  - Set
---
# Niet naar huis
We zijn nu een week in Yaroslavl en we zitten elke dag met vier andere studenten drie uur  in de schoolbanken om Russisch te leren. 's Middags vrij, maar dan moeten we allemaal dingen doen. Cintha en Mark speuren naar biologische winkels en rauwe melk; Karin en ik loodsen onze verhuisde spullen binnen die nog bij de grens staan. We hebben een prima flat op vijf minuten van de uni en op vijf minuten van de kade van de Wolga. Het is erg mooi hier. Er zijn erg veel kleine verschillen, maar alles is ook weer gewoon. Een aantal dingen werken hier niet: Netflix en Twitter -- cold turkey, maar YouTube wel, en als je geld drie maanden vast zet krijg je 20% rente. Plussen en minnen. We proberen nog te snappen wat we hier doen, maar we hebben nog niet gedacht: naar huis.