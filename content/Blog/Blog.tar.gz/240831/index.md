---
title: Blog
subtitle: From First Principle
date: 2024-08-31
hero_classes: text-dark title-h1h2 overlay-light hero-large parallax
hero_image: pexels-toa-heftiba-şinca-1194420.jpg
blog_url: /blog
show_sidebar: true
show_breadcrumbs: true
show_pagination: true
categories:
  - Blog
tags:
  - Set
---
We zitten nu in de derde fase van ons grote project: vakantie. We zitten in een naar kelder-huisje in Duitsland en we hebben net besloten eerder door te gaan naar het prettige huisje in een mooie omgeving in Polen waar we vorig jaar ook waren. Vanmorgen boodschappen gedaan voor de komen dagen: biologische vlees en groenten, want die zijn in Polen lastig te krijgen.

Het grote project zou moeten betekenen dat we ons raar voelen, maar het voelt vooral als vakantie. Het enige wat echt raar voelt is dat ik maar één sleutel heb: de autosleutel. Op een bepaalde manier zijn we dakloos.
![](/blog/images/1728748617010.jpg)
